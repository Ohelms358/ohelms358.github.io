/**
 * Data models
 */
Apperyio.Entity = new Apperyio.EntityFactory({
    "Number": {
        "type": "number"
    },
    "Boolean": {
        "type": "boolean"
    },
    "String": {
        "type": "string"
    }
});
Apperyio.getModel = Apperyio.Entity.get.bind(Apperyio.Entity);

/**
 * Data storage
 */
Apperyio.storage = {

    "input1": new $a.SessionStorage("input1", "Number"),

    "input2": new $a.SessionStorage("input2", "Number"),

    "Answer": new $a.SessionStorage("Answer", "Number")
};