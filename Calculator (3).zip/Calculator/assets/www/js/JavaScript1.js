function finishEquation(){
tempvar = Apperyio.storage.input1.get();
temp = Apperyio.storage.input2.get();
if(tempvar === ""){
  Apperyio.storage.input1.set(0);
}
else{
       Apperyio.storage.set(tempvar);
    }
if(temp === ""){
  Apperyio.storage.input1.set(0);
}
  else{
       Apperyio.storage.input2.set(temp);
  }
}